# Installing packages
pacman::p_load(tidyverse, here, dplyr)

# Reading in reformatted data which is saved as csv
data <- read_csv(here::here("data", "reformatted_data.csv"))
data

# Changing Cell_Line,Treatment and GL (Gene Line) to factor variables
data <- data %>% mutate(across(c(Cell_Line, Treatment, GL), as.factor))
data
