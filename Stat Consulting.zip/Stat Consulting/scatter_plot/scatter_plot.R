# Include: false
pacman::p_load(tidyverse, dplyr, lme4, ggrepel, patchwork,
               showtext, lmerTest, MuMIn, gt)

# Set the theme to a black and white theme
theme_set(theme_bw())

# Add a custom font named "times"
font_add(
  family = "times",
  regular = here::here(
    "figs", "Times New Roman.ttf"  # Path to the regular font file
  )
)

# Enable automatic font rendering
showtext_auto()

# colours
col_path <- c("#81A7CD", "#D2BF9D")

# Wild-type plot (left)
WT_plot <- data %>%
  filter(Cell_Line == "cell_type_101") %>%
  ggplot(aes(Conc, Gene_Expression, color = Treatment, label = GL)) +
  geom_point(aes(fill = Treatment), shape=21, colour = "black", size = 3) +
  geom_label_repel(aes(fill = Treatment),
                   color = "black",
                   min.segment.length = 0,
                   data = ~ subset(., Conc==10),
                   max.overlaps = Inf,
                   nudge_x = 0.5,
                   show.legend = FALSE,
                   family = "times"
  ) +
  theme_bw() +
  scale_x_continuous(minor_breaks = seq(0, 12.5, 0.5), breaks = seq(0, 10, by = 1)) +
  scale_fill_manual(values = col_path, labels = c("Activating factor 42", "Placebo")) +
  labs(
    x = expression(paste("Concentration of Growth Factor (",mu, "g/ml)")),
    y = "Gene Expression"
  ) +
  ggtitle("Cell-type 101")+
  guides(fill = guide_legend(title = "Treatment")) +
  theme(text = element_text(family = "times"))

# cell-type 101 plot (right)
CT101_plot <- data %>%
  filter(Cell_Line == "wild_type") %>%
  ggplot(aes(Conc, Gene_Expression, color = Treatment, label = GL)) +
  geom_point(aes(fill = Treatment), shape=21, colour = "black", size = 3) +
  geom_label_repel(aes(fill = Treatment),
                   color = "black",
                   min.segment.length = 0,
                   data = ~ subset(., Conc==10),
                   max.overlaps = Inf,
                   nudge_x = 0.5,
                   show.legend = FALSE,
                   family = "times"
  ) +
  theme_bw() +
  scale_x_continuous(minor_breaks = seq(0, 12.5, 0.5), breaks = seq(0, 10, by = 1)) +
  scale_fill_manual(values = col_path, labels = c("Activating factor 42", "Placebo")) +
  labs(
    x = expression(paste("Concentration of Growth Factor (",mu, "g/ml)")),
    y = "Gene Expression"
  ) +
  ggtitle("Wild-type") +
  guides(fill = guide_legend(title = "Treatment")) +
  theme(text = element_text(family = "times"))


# combining plots
patchwork <- WT_plot + CT101_plot + plot_annotation(tag_levels = 'A') +
  plot_layout(guides = "collect") &
  theme(legend.position = "bottom")

patchwork

# # saving the plot as a tiff file (9in x 6in) with a resolution of 500
# ggsave(
#   filename = here::here("data", "gene_plot_times.tiff"),
#   plot = patchwork,
#   width = 9,
#   height = 6,
#   dpi = 500,
#   units = "in"
# )







