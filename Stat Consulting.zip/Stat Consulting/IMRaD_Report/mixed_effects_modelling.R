pacman::p_load(lme4, MuMIn)

# 3-way interaction model
# Fit linear mixed effects model
M1_Full <- lmer(Gene_Expression ~ Conc * Cell_Line * Treatment + (1|GL), data = data)
M1_Full



# Perform an analysis of variance (ANOVA) on the model
M1_ANOVA <- anova(M1_Full)
M1_ANOVA

# Perform a random effects (RANOVA) on the model
M1_RANOVA <- ranova(M1_Full)
M1_RANOVA