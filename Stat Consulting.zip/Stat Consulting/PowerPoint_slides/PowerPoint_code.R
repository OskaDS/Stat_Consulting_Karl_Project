# Installing packages
pacman::p_load(tidyverse, plyr, dplyr, showtext, grDevices, ggrepel, ggplot2, patchwork, harrypotter, here)

## Add Times New Roman font
font_add(
  family = "times",
  regular = here::here(
    "Desktop","Stat Consulting", "Times New Roman.ttf"
  )
)

# Enable automatic text rendering
showtext_auto()




### SLIDE TWO ###

# Gene Expression vs Concentration for Wild type cell with linear trend line
data %>%
  filter(Cell_Line == "wild_type") %>%
  ggplot(aes(x = Conc, y = Gene_Expression, color = Treatment)) +
  geom_point() +
  geom_smooth(method = "lm", alpha = .15) +
  labs(title = "Gene Expression vs Growth Factor", subtitle = "Cell Line: Wild Type",
       x = "Concentration of Growth Factor \n (mg/ml)", y = "Gene Expression", color = "Treatment Type") +
  scale_color_manual(labels = c("Label A", "Label B")) +
  harrypotter::scale_color_hp_d("RavenClaw") +
  theme(text = element_text(family = "times", size = 10))

## Making Corresponding Linear Models
# Placebo
wild_type_placebo <- data %>%
  filter(Cell_Line == "wild_type" & Treatment == "placebo")
# Gene Expression vs Concentration using placebo for Wild type cell linear model
lm(Gene_Expression~Conc, data = wild_type_placebo)

# Activating factor 42
wild_type_fct42 <- data %>%
  filter(Cell_Line == "wild_type" & Treatment == "activating_factor_42")
# Gene Expression vs Concentration using activating factor 42 treatment
# for Wild type cell linear model
lm(Gene_Expression~Conc, data = wild_type_fct42)




### SLIDE THREE ###

# Gene Expression vs Concentration for cell type 101
# with linear trend line
data %>%
  filter(Cell_Line == "cell_type_101") %>%
  ggplot(aes(x = Conc, y = Gene_Expression, color = Treatment)) +
  geom_point() +
  geom_smooth(method = "lm", alpha = .15) +
  labs(title = "Gene Expression vs Growth Factor", subtitle = "Cell Line: Cell Type 101",
       x = "Concentration of Growth Factor \n(mg/ml)", y = "Gene Expression", color = "Treatment Type") +
  theme(text = element_text(family = "times", size = 10)) +
  harrypotter::scale_color_hp_d("RavenClaw")

## Making Linear Models
# Placebo
type_101_placebo <- data %>%
  filter(Cell_Line == "cell_type_101" & Treatment == "placebo")
# Gene Expression vs Concentration using activating placebo
# for cell type 101 linear model
lm(Gene_Expression~Conc, data = type_101_placebo)

# Activating factor 42
type_101_fct42 <- data %>%
  filter(Cell_Line == "cell_type_101" & Treatment == "activating_factor_42")
# Gene Expression vs Concentration using activating factor 42 treatment
# for cell type 101 linear model
lm(Gene_Expression~Conc, data = type_101_fct42)




### SLIDE FOUR ###

# Boxplot of Gene Expression vs Concentration for wild type cell
data %>%
  filter(Cell_Line == "wild_type") %>%
  ggplot(aes(x = Treatment, y = Gene_Expression, fill = Treatment)) +
  geom_boxplot() +
  labs(title = "Gene Expression vs Treatment", subtitle = "Cell Line: Wild Type",
       x = " ", y = "Gene Expression", fill = "Treatment Type") +
  theme(text = element_text(family = "times", size = 10)) +
  harrypotter::scale_fill_hp_d("RavenClaw")

# scale_fill_brewer(palette="Royal1")
# 5 number summary of boxplots
summary(wild_type_placebo$Gene_Expression)
summary(wild_type_fct42$Gene_Expression)



### SLIDE FIVE ###

# Boxplot of Gene Expression vs Concentration for cell type 101
data %>%
  filter(Cell_Line == "cell_type_101") %>%
  ggplot(aes(x = Treatment, y = Gene_Expression, fill = Treatment)) +
  geom_boxplot() +
  labs(title = "Gene Expression vs Treatment", subtitle = "Cell Line: Cell Type 101",
       x = "", y = "Gene Expression", fill = "Treatment Type") +
  theme(text = element_text(family = "times", size = 10)) +
  harrypotter::scale_fill_hp_d("RavenClaw")

# 5 number summary of boxplots
summary(type_101_placebo$Gene_Expression)
summary(type_101_fct42$Gene_Expression)



### SLIDE SIX ###

# Gene Expression vs Growth Factor scatter plot using activating factor 42 treatment
data %>%
  filter(Treatment == "activating_factor_42") %>%
  ggplot(aes(x = Conc, y = Gene_Expression, color = Cell_Line)) +
  geom_point() +
  geom_smooth(method = "lm", alpha = .15) +
  labs(title = "Gene Expression vs Growth Factor \nUsing Activating Factor 42 Treatment",
       x = "Concentration of Growth Factor \n(mg/ml)", y = "Gene Expression") +
  theme(text = element_text(family = "times", size = 10)) +
  harrypotter::scale_color_hp_d("RavenClaw")

## Making Corresponding Linear Models
# Gene Expression vs Concentration using activating factor 42 treatment
# for Wild type cell linear model
lm(Gene_Expression~Conc, data = wild_type_fct42)

# Gene Expression vs Concentration using activating factor 42 treatment
# for cell type 101 linear model
lm(Gene_Expression~Conc, data = type_101_fct42)










