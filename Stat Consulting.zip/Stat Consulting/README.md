README
================
Oska Dubsky-Smith
6/3/23

## Outline

This document serves as a detailed guide, presenting a comprehensive
step-by-step timeline that summarizes all the deliverables requested by
Research Assistant Dr. Karl Barator from the Institute of Omics via
email.

The main focus of this study revolves around analyzing the impact of
treatment on the relationship between the concentration of the growth
factor and gene expression. Through this README, we aim to provide a
clear overview of our research question and the objectives we aim to
achieve.

## Data

To access the unaltered raw data for our study, navigate to the
**raw_data** folder in this repository. Inside, you will find a file
named **karl_raw_data.xlsx**, which contains the complete dataset
provided by Dr. Karl Barator. The data was shared via a Google Docs
link, as indicated in Karl’s email. Additionally, you can refer to the
text file named **PowerPoint_email** to access the relevant email
correspondence.

The raw dataset consists of 8 separate Excel worksheets, each containing
information on 88 gene expression measurements. It encompasses various
variables, including:

- **Conc**: This variable represents the concentration of the growth
  factor, ranging from 0 to 10 micrograms/mL.
- **Gene_Expression**: This column showcases the corresponding gene
  expressions of the cells.
- **Cell_Line**: Two types of cells are featured: ‘wild_type’ and
  ‘cell_type_101’.
- **Treatment**: This variable indicates the type of treatment
  administered to the cells, categorized as either ‘placebo’ or
  ‘activating_factor_42’.
- **GL**: This column captures the corresponding gene lines for each
  cell, denoted as CsE, bNo, JZC, fUg, jEK, and Hoe.

Each column in the dataset represents a specific variable, while each
row represents an individual observation.

By exploring this dataset, we aim to gain insights into the relationship
between the concentration of the growth factor and gene expression,
shedding light on the effects of treatment on this relationship.

## Data Cleaning

For all data cleaning-related tasks, please refer to the **data** folder
in this repository. It contains the necessary files and information to
ensure the cleanliness and integrity of our dataset.

To access the code utilized for data cleaning, navigate to the
**data_cleaning.R** file. This script outlines the specific steps taken
to clean and preprocess the raw data. It encompasses various procedures
to handle missing values and ensure consistency throughout the dataset.

In the process of merging the data, each Excel worksheet was manually
combined into a single worksheet to create a comprehensive dataset. To
address missing data, a gene expression value of $-99$ identified in
worksheet GL-fUg cell B11 was converted to an NA value. Prior to making
this adjustment, clarification was sought from Karl to ensure accuracy
and validity. You can review the email correspondence in the
**data_cleaning_email** text file for further details.

The resultant cleaned dataset was saved as a CSV file called
**reformatted_data.csv**. It includes columns representing the
concentration, gene expression, cell line, and gene line variables.
Additionally, to facilitate analysis and maintain consistency, the cell
line, treatment, and gene line variables were converted from character
variables to factor variables.

## Deliverable 1: PowerPoint Slides

To address the first deliverable set by Dr. Barator, we have organized
all the relevant materials within the **PowerPoint_slides** folder.
Here’s an overview of the contents:

- **PowerPoint_Slides_for_Karl.pptx**: This file contains the PowerPoint
  presentation emailed to Dr. Barator, exploring the effect of treatment
  on the relationship between the growth factor and gene expression. It
  consists of three scatter plots and two box plots, visually depicting
  the findings of our analysis.

- **PowerPoint_code.R**: The code used to generate the plots showcased
  in the PowerPoint slides can be found in this file. You will find the
  specific R code for creating the scatter plots, fitting linear models,
  and generating the necessary visualizations.

- **Tables_for_Karl.docx**: This document contains the tables presented
  in the PowerPoint slides. It provides summarized information derived
  from the linear models and the box plots, enhancing the understanding
  of the observed trends. The code for generating these tables is
  included in the PowerPoint_code.R file.

- **PowerPoint_email**: This email correspondence captures Dr. Barator’s
  communication wherein he specified his requirements and expectations
  regarding the PowerPoint slides. It served as a valuable source of
  guidance for understanding the deliverable expectations and tailoring
  our presentation accordingly.

The scatter plots display the relationship between gene expression and
the growth factor, with colors representing different treatment
conditions and separate plots for each cell type. Linear models were
fitted to each scatter plot, and the respective model summaries are
presented in the tables within the **Tables_for_Karl.docx** file.

Similarly, the box plots depict the relationship between gene expression
and treatment for each cell line, along with a summary of the data using
five-number summaries. The code used to generate these box plots and the
corresponding summary table can be found in the **PowerPoint_code.R**
file.

Additionally, there is a scatter plot specifically focusing on gene
expression versus the growth factor for the Activating Factor 42
treatment condition. The code to create this plot and the accompanying
table is also found in the **PowerPoint_code.R** file.

These PowerPoint slides, along with the supporting code and tables,
serve to provide a visual and statistical representation of the
relationship between the growth factor, treatment, and gene expression,
as outlined in the first deliverable requested by Dr. Barator.

## Deliverable 2: Scatterplot as .tif

To address the second deliverable set by Dr. Barator, we have organized
all the relevant materials within the **scatter_plot** folder. Here’s an
overview of the contents:

- **gene_plot.pdf**: This file displays the original scatter plot that
  was initially sent to Dr. Barator for reference.

- **scatter_plot.R**: The code required to reproduce the scatter plot
  according to Dr. Barator’s specifications can be found in this file.
  The code includes modifications such as changing the font to Times New
  Roman and updating the x-axis label based on an in-person conversation
  with Dr. Barator.

- **scatter_plot_email**: This text file contains the email request from
  Dr. Barator, specifying the requirements for reproducing the scatter
  plot.

- **gene_plot_times.tiff**: The reproduced scatter plot adhering to
  Dr. Barator’s criteria is saved as a TIFF file with the filename
  **gene_plot_times.tiff**. This file can be accessed and reviewed.

Given the size of the TIFF file, sending it directly via email posed a
challenge due to limitations in file size. To overcome this, the scatter
plot was uploaded to Google Drive, and a link to the file was shared
with Dr. Barator for easy access. The Google Drive link to the
reproduced scatter plot is:
https://drive.google.com/file/d/1QRqUTDer88nZ3AtMvKuAqdF_ePBiB02L/view.

## Deliverable 3: Sample Size Calculation

All materials related to this deliverable are located in the
sample_size_calculation folder.

The third deliverable requested by Dr. Barator was a sample size
calculation. According to the email from Dr. Barator as seen in
**sample_size_calculation_email**, a linear regression analysis of gene
expression was to be performed with the predictors concentration, cell
age, treatment (two levels), cell type (two levels), and media (two
levels). The email also mentioned that a previous study obtained an
$R^2$ value of 0.1 between the predictors and the response level.
Dr. Barator specified a desired power of 90% and a significance level of
0.05, and wanted to know the total number of samples required.

To carry out this calculation, the code in **sample_size_calculation.R**
was used. The `pwr.f2.test` function from the `pwr` package was employed
for the sample size estimation. This function enables power analysis for
the F-test in a multiple linear regression model.

The `pwr.f2.test` function takes the following parameters:

- $u$: The number of predictors $k$, excluding the intercept.
- $v$: The denominator degrees of freedom defined as $n - k - 1$. This
  parameter represents the unknown sample size ($n$) in this case.
- f2: The effect size, calculated as $f^2 = \frac{R^2}{1 - R^2}$.
- sig.level: The required significance level.
- power: The desired power of the test.

By providing four out of the five parameters, the function calculates
the missing parameter. In this scenario, the aim was to determine the
sample size ($n$), so the function was used to compute the value of $v$.
Subsequently, the formula $n = v + k + 1$ was employed to calculate the
required sample size.

Since the effect size ($f^2$) was not explicitly given, it was estimated
using the formula $f^2 = \frac{R^2}{1 - R^2}$ from page 149 of the book
“Sample Size Determination and Power” by Thomas P. Ryan.

Using the `pwr.f2.test` function with the following inputs:

- $u$ = 5 (number of predictors)
- $v$ = NULL (unknown sample size)
- f2 = 0.1/0.9 (effect size calculated from $R^2$)
- sig.level = 0.05 (required significance level)
- power = 0.9 (desired power of the test)

The value of $v$ was determined to be 148 (rounded up to the nearest
integer). By rearranging the formula, the required sample size was
calculated as $n = 148 + 5 + 1 = 154$.

By conducting this sample size calculation, it can be ensured that
Dr. Barator’s study will have sufficient statistical power (90%) to
detect the desired effect size with a significance level of 0.05, by
collecting a total of 154 samples.

## Deliverable 4: IMRaD Report

All materials related to this deliverable are located in the
**IMRaD_report** folder.

The final deliverable was an IMRaD report summarizing the steps involved
in building a predictive model of gene expression. The report was
written using the Quarto document format. It provides a comprehensive
overview of the process of creating a mixed effects model with a
three-way interaction term to predict gene expression.

The code for constructing the mixed effects model with a three-way
interaction term can be found in the **mixed_effects_model.R** file.
However, all the detailed information and analysis results are included
in the IMRaD report, which is named **IMRaD_report.qmd**. The
corresponding bibliography for the report is provided in the
**bibliography.bib** text file. The report was then compiled into a PDF
format, which can be viewed in the **IMRaD_report.pdf** file. It was
sent to Dr. Barator via email as the final deliverable.

The IMRaD report provides a structured and comprehensive summary of the
entire process involved in developing the predictive model of gene
expression, ensuring that all the steps and analysis procedures are
clearly documented and presented in a professional format.

## Miscellaneous

All figures produced in this collaboration can also be found in the figs
folder.
