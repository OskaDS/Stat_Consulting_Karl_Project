# Loading pwr package
pacman::p_load(pwr) 

# r squared value
r2 <- 0.1

# number of predictors not including intercept
k <- 5

# power
power <- 0.9

# significance level
alpha <- 0.05

# effect size f2
f2 <- r2/(1-r2)

# calculating denominator degrees of freedom
den_dof <- pwr.f2.test(u = k, v = NULL, f2 = f2, sig.level = alpha, power = power)
den_dof

# calculating sample size
# v = n - k - 1 => n = v + k + 1
n <- ceiling(den_dof$v + k + 1)
n

# good link
# https://data-se.netlify.app/2018/07/24/power-calculation-for-the-general-linear-model/

